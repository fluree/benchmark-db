#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
RUN_DIR=$PWD
mkdir -p results
exec > >(tee -a results/wikidata.log) 2>&1
trap 'rc=$?; echo "$rc" > results/wikidata.exit; python3 server.py stop; sync' EXIT
python3 - <<'PY'
import hashlib,json
from pathlib import Path
m=json.loads(Path('candidate-build.json').read_text())
assert hashlib.sha256(Path('fluree').read_bytes()).hexdigest()==m['binary_sha256']
PY
lscpu > results/lscpu.txt
free -b > results/memory.txt
sha256sum queries/*.sparql > results/query-hashes.sha256
python3 server.py start --binary "$RUN_DIR/fluree" --kind wikidata --port 8090 --label "${SERVER_LABEL:-candidate-5529b53}"
# Load the retained ledger before timing; startup is not a query measurement.
curl -fsS --max-time 600 -H 'Content-Type: application/sparql-query' \
  -H 'Accept: application/sparql-results+json' \
  --data 'SELECT ?s ?p ?o WHERE { ?s ?p ?o } LIMIT 1' \
  http://127.0.0.1:8090/v1/fluree/query/wikidata:main > results/startup-prime.json
pidstat -h -r -u -p "$(python3 -c 'import json;print(json.load(open("server-state.json"))["pid"])')" 5 > results/pidstat.txt &
telemetry_pid=$!
if [[ ! -f results/target.tsv ]]; then
bash run_benchmark.sh --endpoint http://127.0.0.1:8090/v1/fluree/query/wikidata:main \
  --queries queries -q TI3-40.sparql -w 1 -r 3 -t 120 \
  --save-outputs results/target-outputs -o results/target.tsv
else
python3 summarize.py results/target.tsv > results/target_summary.tsv
fi
python3 - <<'PY'
import csv
rows=list(csv.DictReader(open('results/target.tsv'),delimiter='\t'))
assert len(rows)==3 and all(r['status']=='200' for r in rows), rows
PY
python3 probe.py --endpoint http://127.0.0.1:8090/v1/fluree/query/wikidata:main \
  --queries queries --glob TI3-40.sparql --output results/target-json --timeout 120 --warmups 0 --runs 1
bash run_benchmark.sh --endpoint http://127.0.0.1:8090/v1/fluree/query/wikidata:main \
  --queries queries -w 1 -r 3 -t 120 \
  --save-outputs results/full-outputs -o results/full.tsv
python3 - <<'PY'
import csv,json,datetime
rows=list(csv.DictReader(open('results/full_summary.tsv'),delimiter='\t'))
out=dict(total=len(rows),successes=sum(r['status']=='200' for r in rows),
         failures=[r for r in rows if r['status']!='200'],
         completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
open('results/outcomes.json','w').write(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
PY
kill "$telemetry_pid" || true
