#!/usr/bin/env python3
"""Archive this run's evidence after its processes and telemetry have stopped."""
import datetime,hashlib,json,tarfile
from pathlib import Path
h=Path(__file__).resolve().parent;archive=h/'artifacts.tar.gz'
assert not archive.exists(), 'Preserve previous archive'
with tarfile.open(archive,'w:gz') as tar:
    tar.add(h/'results',arcname='results')
    for name in ['queries','exported-bi','selected-q4','aggregate-q4']:
        if (h/name).is_dir():tar.add(h/name,arcname=name)
    for pattern in ['*.py','*.sh','*.java','*build.json','*source.json','job.json','server-state.json','telemetry-state.json','driver-parity.json','keepalive.patch']:
        for p in h.glob(pattern):tar.add(p,arcname=p.name)
record=dict(file=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),created_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
(h/'artifact-manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
