#!/usr/bin/env python3
"""Save exact query bodies, complete results and individual HTTP request timing."""
import argparse, datetime, hashlib, http.client, json, time
from pathlib import Path
from urllib.parse import urlsplit

p=argparse.ArgumentParser()
p.add_argument('--endpoint',required=True)
p.add_argument('--queries',required=True,type=Path)
p.add_argument('--glob',default='*.sparql')
p.add_argument('--output',required=True,type=Path)
p.add_argument('--timeout',type=int,default=300)
p.add_argument('--warmups',type=int,default=1)
p.add_argument('--runs',type=int,default=3)
a=p.parse_args()
a.output.mkdir(parents=True,exist_ok=False)
u=urlsplit(a.endpoint)
conn=http.client.HTTPConnection(u.hostname,u.port,timeout=a.timeout)
records=[]
queries=sorted(a.queries.glob(a.glob))
assert queries, 'No matching queries'
for q in queries:
    body=q.read_bytes()
    (a.output/q.name).write_bytes(body)
    for i in range(a.warmups+a.runs):
        rec=dict(query=q.name,query_sha256=hashlib.sha256(body).hexdigest(),
                 phase='warmup' if i<a.warmups else 'measured',run=i,
                 started_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
        start=time.perf_counter()
        try:
            conn.request('POST',u.path,body,{'Content-Type':'application/sparql-query','Accept':'application/sparql-results+json'})
            resp=conn.getresponse();raw=resp.read()
            rec.update(time_ms=(time.perf_counter()-start)*1000,status=resp.status,
                       content_type=resp.getheader('Content-Type'))
            output=f'{q.stem}-run{i}.json'
            (a.output/output).write_bytes(raw)
            rec.update(response_file=output,response_sha256=hashlib.sha256(raw).hexdigest())
            if resp.status==200:
                result=json.loads(raw)
                rec['rows']=len(result['results']['bindings'])
        except Exception as e:
            rec.update(time_ms=(time.perf_counter()-start)*1000,error=str(e))
            conn.close()
        records.append(rec)
        (a.output/'samples.json').write_text(json.dumps(records,indent=2)+'\n')
        print(json.dumps(rec),flush=True)
        if rec.get('status') != 200 or 'error' in rec:
            conn.close()
            raise SystemExit(2)
conn.close()
