#!/usr/bin/env python3
"""Compare the first measured TSV response of each WGPB query between two runs on the same retained store:
byte identity, header, and row multiset. Usage: answer-compare.py REF_DIR NEW_DIR OUT.json"""
import collections, json, sys
from pathlib import Path
ref, new, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
qs = sorted(p.name[:-len('-run1.tsv')] for p in new.glob('*-run1.tsv'))
rows = []
for q in qs:
    a = (ref / f'{q}-run1.tsv').read_bytes(); b = (new / f'{q}-run1.tsv').read_bytes()
    al, bl = a.decode().splitlines(), b.decode().splitlines()
    rows.append(dict(query=q, ref_rows=len(al) - 1, new_rows=len(bl) - 1, identical_bytes=a == b,
                     same_header=al[:1] == bl[:1], same_row_multiset=collections.Counter(al[1:]) == collections.Counter(bl[1:])))
s = dict(compared_queries=len(rows), identical_bytes=sum(r['identical_bytes'] for r in rows),
         same_row_multiset=sum(r['same_row_multiset'] for r in rows),
         differences=[r['query'] for r in rows if not r['same_row_multiset']], queries=rows)
out.write_text(json.dumps(s, indent=2) + '\n')
print({k: v for k, v in s.items() if k != 'queries'})
