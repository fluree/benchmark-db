#!/usr/bin/env python3
"""Validate every TI3-40 solution via subject lookups, without object-bound joins."""
import argparse,collections,hashlib,json,time,urllib.request
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--endpoint',required=True);p.add_argument('--response',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args()
a.output.mkdir(parents=True,exist_ok=False)
rows=json.loads(a.response.read_text())['results']['bindings'];assert len(rows)==1000
def term(x):return json.dumps(x,sort_keys=True,separators=(',',':'))
checks=[]
for var,predicate in [('y','P2884'),('z','P2547'),('u','P1082')]:
    subjects=sorted({r[var]['value'] for r in rows});assert all(r[var]['type']=='uri' for r in rows)
    assert all('<' not in s and '>' not in s for s in subjects)
    query='SELECT ?s ?value WHERE { VALUES ?s { '+' '.join('<'+s+'>' for s in subjects)+' } ?s <http://www.wikidata.org/prop/direct/'+predicate+'> ?value . }'
    (a.output/(predicate+'.sparql')).write_text(query+'\n')
    req=urllib.request.Request(a.endpoint,data=query.encode(),headers={'Content-Type':'application/sparql-query','Accept':'application/sparql-results+json'})
    start=time.monotonic()
    with urllib.request.urlopen(req,timeout=300) as response:raw=response.read()
    (a.output/(predicate+'.json')).write_bytes(raw)
    actual={(r['s']['value'],term(r['value'])) for r in json.loads(raw)['results']['bindings']}
    missing=[i for i,r in enumerate(rows) if (r[var]['value'],term(r['x'])) not in actual]
    checks.append(dict(predicate=predicate,subjects=len(subjects),returned_pairs=len(actual),missing_solution_indices=missing,valid=not missing,diagnostic_seconds=time.monotonic()-start))
summary=dict(valid=all(c['valid'] for c in checks),solutions=len(rows),distinct_solutions=len({term(r) for r in rows}),source_response_sha256=hashlib.sha256(a.response.read_bytes()).hexdigest(),method='Check all three source triples of every solution using only subject-bound lookups. Exact RDF binding comparison, no object-bound seek or multi-pattern join.',checks=checks)
(a.output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
raise SystemExit(0 if summary['valid'] else 2)
