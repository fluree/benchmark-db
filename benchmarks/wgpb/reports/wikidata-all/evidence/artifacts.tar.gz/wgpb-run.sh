#!/bin/bash
# WGPB 850-query run, Fluree v4.2.7 (built from release/v4.2.7) on the existing Wikidata all-dump ledger. No import.
set -euo pipefail
R=~/results-v427; H=~/harness; BIN=~/bin/fluree-v427
mkdir -p $R; exec > >(tee -a $R/wgpb.log) 2>&1
trap 'r=$?; echo $r > $R/wgpb.exit; pkill -f "fluree-v427 server run" 2>/dev/null; true' EXIT
log() { echo "[$(date -u +%F\ %T)] $*"; echo "$*" > $R/STAGE; }
ulimit -n 1048576
EP=http://127.0.0.1:8090/v1/fluree/query/wikidata:main
$BIN --version | tee $R/version.txt; sha256sum $BIN | tee -a $R/version.txt
lscpu > $R/lscpu.txt; free -b > $R/memory.txt
sha256sum $H/benchmarks/wgpb/queries/*.sparql > $R/query-hashes.sha256
cd ~/ledger
FLUREE_CACHE_MAX_MB=88311 $BIN server run --listen-addr 127.0.0.1:8090 --log-level warn > $R/server.log 2>&1 &
spid=$!
for i in $(seq 1 1800); do curl -fsS http://127.0.0.1:8090/health >/dev/null 2>&1 && break; sleep 1; done
log "prime"
curl -fsS --max-time 600 -H 'Content-Type: application/sparql-query' -H 'Accept: application/sparql-results+json' \
  --data 'SELECT ?s ?p ?o WHERE { ?s ?p ?o } LIMIT 1' $EP > $R/startup-prime.json
log "count"
curl -fsS --max-time 14400 -H 'Content-Type: application/sparql-query' -H 'Accept: text/tab-separated-values' \
  --data 'SELECT (COUNT(*) AS ?c) WHERE {?s ?p ?o}' $EP | tee $R/count.tsv
pidstat -h -r -u -p $spid 5 > $R/pidstat.txt & tp=$!
log "TI3-40 probe"
curl -fsS --max-time 120 -H 'Content-Type: application/sparql-query' -H 'Accept: application/sparql-results+json' \
  --data-binary @$H/benchmarks/wgpb/queries/TI3-40.sparql $EP > $R/TI3-40-probe.json
for p in 1 2; do
  log "sweep $p"; cd $R
  bash $H/common/run_benchmark.sh --endpoint $EP --queries $H/benchmarks/wgpb/queries -r 3 -w 1 -t 120 \
    --save-outputs $R/query-outputs-p$p -o $R/fluree-p$p.tsv > $R/bench-p$p.log 2>&1
  python3 $H/common/summarize.py $R/fluree-p$p.tsv > $R/fluree-p${p}_summary.tsv
done
grep VmHWM /proc/$spid/status > $R/server-rss.txt || true
kill $tp || true
log "WGPB DONE"; trap - EXIT; echo 0 > $R/wgpb.exit
# server left running for follow-up checks
