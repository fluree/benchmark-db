#!/usr/bin/env python3
"""Control only this run's server process, preserving retained database directories."""
import argparse, datetime, hashlib, json, os, signal, subprocess, time, urllib.request
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('action', choices=['start', 'stop'])
p.add_argument('--binary', type=Path)
p.add_argument('--ledger', type=Path, default=Path('/home/ubuntu/ledger'))
p.add_argument('--kind', choices=['wikidata', 'bsbm'], default='bsbm')
p.add_argument('--label', default='candidate')
p.add_argument('--port', type=int, default=8182)
a = p.parse_args()
here = Path(__file__).resolve().parent
state = here / 'server-state.json'
results = here / 'results'; results.mkdir(exist_ok=True)

def alive(pid):
    try:
        return Path(f'/proc/{pid}/stat').read_text().split(') ', 1)[1][0] not in 'ZX'
    except FileNotFoundError:
        return False

if a.action == 'stop':
    if not state.exists():
        raise SystemExit(0)
    m = json.loads(state.read_text()); pid = m['pid']
    if alive(pid):
        assert str(Path(f'/proc/{pid}/exe').resolve()) == m['binary'], 'PID identity changed'
        os.kill(pid, signal.SIGTERM)
        for _ in range(180):
            if not alive(pid): break
            time.sleep(1)
        if alive(pid):
            raise RuntimeError('Server did not stop gracefully; preserve for investigation')
    m['stopped_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    state.write_text(json.dumps(m, indent=2)+'\n')
    print(json.dumps(m))
    raise SystemExit(0)

assert a.binary and a.binary.is_file()
assert (a.ledger / '.fluree').is_dir(), 'Retained database missing; never import automatically'
if state.exists():
    assert not alive(json.loads(state.read_text())['pid']), 'Existing run server still active'
env = os.environ.copy()
for k in list(env):
    if k.startswith('FLUREE_'): del env[k]
if a.kind == 'wikidata':
    mem_kb = int(next(x for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemTotal:')).split()[1])
    env['FLUREE_CACHE_MAX_MB'] = str(round(mem_kb/1024*0.35))
    address = '127.0.0.1'
else:
    env.update(FLUREE_REINDEX_MIN_BYTES='2097152', FLUREE_STORAGE_FSYNC='1', FLUREE_INDEXING_ENABLED='true')
    address = '0.0.0.0'
binary = a.binary.resolve()
log = results / (a.label + '-server.log')
assert not log.exists(), 'Use a unique server label'
cmd = [str(binary), 'server', 'run', '--listen-addr', f'{address}:{a.port}', '--log-level', 'warn']
with log.open('w') as f:
    proc = subprocess.Popen(cmd, cwd=a.ledger, env=env, stdout=f, stderr=subprocess.STDOUT,
                            stdin=subprocess.DEVNULL, start_new_session=True)
m = dict(pid=proc.pid, binary=str(binary), binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
         binary_version=subprocess.check_output([str(binary),'--version'], text=True).strip(),
         command=cmd, ledger=str(a.ledger), read_only_workload=True,
         environment={k:v for k,v in env.items() if k.startswith('FLUREE_')},
         started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), label=a.label)
state.write_text(json.dumps(m, indent=2)+'\n')
(results/(a.label+'-server.json')).write_text(json.dumps(m, indent=2)+'\n')
for _ in range(600):
    if proc.poll() is not None:
        raise RuntimeError('Server exited: '+log.read_text()[-3000:])
    try:
        with urllib.request.urlopen(f'http://127.0.0.1:{a.port}/health', timeout=2) as r:
            if r.status == 200:
                print(json.dumps(m)); break
    except Exception:
        pass
    time.sleep(1)
else:
    raise RuntimeError('Server startup deadline exceeded; inspect server log')
